#!/usr/bin/env python3
import csv
from urllib.parse import quote_plus

# Product data with manually extracted information
products_data = [
    {
        "name": "Dipoo Self-Cleaning Slicker Brush",
        "price": "$8-$10",
        "rating": "4.6/5",
        "description": "A self-cleaning slicker brush for dogs (and cats) that gently removes loose undercoat fur, tangles, and dirt. It has fine bent bristles with a retractable mechanism – after brushing, you press a button to release the collected hair, making cleanup easy. Suitable for short or long coats, it helps reduce shedding and keeps the coat healthy."
    },
    {
        "name": "PAWFUME Deshedding Dog Shampoo & Conditioner (Show Dog Scent)",
        "price": "$12-$16",
        "rating": "4.5/5",
        "description": "A premium 2-in-1 deshedding shampoo and conditioner formulated to reduce shedding and nourish the coat. pH-balanced, hypoallergenic, and infused with salon-quality botanicals and conditioners to detangle fur and soothe skin. The Show Dog scent blend (white lily, powdery musk, and amber) leaves your pup smelling fresh."
    },
    {
        "name": "oneisall Low-Noise Dog Grooming Clippers Kit",
        "price": "$30-$40",
        "rating": "4.5/5",
        "description": "A complete electric clipper kit for home dog grooming. This cordless rechargeable clipper is designed for trimming dogs' fur (even thick or matted coats) with minimal noise – it runs quietly to avoid scaring pets. Features stainless steel fixed blade and ceramic moving blade for sharp, safe cutting."
    },
    {
        "name": "Hansprou High-Power 12V Professional Dog Clipper (Detachable Blade)",
        "price": "$30-$45",
        "rating": "4.7/5",
        "description": "A heavy-duty, corded dog grooming clipper equipped with a powerful 12V rotary motor. This professional-grade clipper has a detachable blade design, allowing easy blade changes and cleaning. Strong enough for thick, heavy coats that can be challenging for battery clippers."
    },
    {
        "name": "Andis UltraEdge 2-Speed Detachable Blade Clipper (Model AGC2)",
        "price": "$120-$150",
        "rating": "4.3/5",
        "description": "A professional-quality Andis grooming clipper commonly used by pet groomers. Features two speeds and a cool-running rotary motor, suitable for all coat types. The detachable UltraEdge blade system allows you to swap blade sizes for different lengths."
    },
    {
        "name": "3-Pack Silicone Dog Bath & Grooming Brushes",
        "price": "Under $10",
        "rating": "4.5/5",
        "description": "A set of three handheld silicone bath brushes in assorted colors. These flexible scrubber brushes are used during bath time to work shampoo into the coat, or for gentle massage grooming on wet or dry fur. They have an adjustable ring grip/strap for your hand."
    },
    {
        "name": "LED Light Pet Nail Clipper (with Safety Quick Sensor)",
        "price": "$10-$15",
        "rating": "4.4/5",
        "description": "A nail trimmer for dogs and cats that includes a built-in LED light to illuminate the nail's quick (the blood vessel) for safer trimming. The clipper has sharp stainless steel blades and often a magnifier guard attached to clearly see the nail and prevent over-cutting."
    },
    {
        "name": "LEYOUFU Cordless Dog Paw Trimmer (Mini Grooming Clipper)",
        "price": "$9-$15",
        "rating": "4.1/5",
        "description": "A small, cordless electric trimmer specifically made for grooming sensitive or hard-to-reach areas like paws, face, ears, and around the eyes. Has a narrow blade with rounded tips to safely trim fur between paw pads or do detail work on small dogs and cats."
    },
    {
        "name": "IPX5 Waterproof Dog Hair Clipper (Low-Noise Cordless Trimmer)",
        "price": "$25-$40",
        "rating": "4.5/5",
        "description": "A waterproof rechargeable pet clipper that can be used on wet or dry fur – handy for grooming during bath time or for easy cleaning under running water. Features detachable titanium and ceramic blade, two or three speed settings, and runs quietly."
    },
    {
        "name": "FURBB Five-Finger Pet Grooming Glove (Deshedding Mitt)",
        "price": "$8-$12",
        "rating": "4.2/5",
        "description": "A flexible grooming glove with rubberized nodules on the palm and fingers, used to massage your pet and remove loose hair. Fits on your hand and allows you to brush your dog by petting them. Great for dogs that are anxious about brushes."
    },
    {
        "name": "Gonicc Dog & Cat Nail Clippers with Safety Guard",
        "price": "$10-$13",
        "rating": "4.6/5",
        "description": "A best-selling nail clipper for pets, known for its sharp blades and built-in safety guard. Made of high-quality stainless steel with non-slip ergonomic handles. Includes a quick safety stop and hidden nail file in the handle for smoothing edges after clipping."
    },
    {
        "name": "FURminator Undercoat Deshedding Tool (for Dogs)",
        "price": "$20-$35",
        "rating": "4.7/5",
        "description": "The iconic FURminator deshedding tool, designed to remove loose undercoat hair and reduce shedding by up to 90%. Has a stainless steel edge that reaches deep beneath the topcoat to gently pull out loose fur without cutting the skin or top hair."
    },
    {
        "name": "Earth Rated Dog Grooming Wipes (Unscented) – 100 Count",
        "price": "$8-$10",
        "rating": "4.6/5",
        "description": "Thick, hypoallergenic grooming wipes for dogs and cats made by Earth Rated. These plant-based wipes are alcohol-free and gentle, infused with aloe vera, shea butter, and chamomile to clean and moisturize your pet's fur and paws."
    },
    {
        "name": "Casfuy Rechargeable Dog Nail Grinder (Quiet Electric Trimmer)",
        "price": "$19-$30",
        "rating": "4.5/5",
        "description": "A veterinarian-recommended electric nail grinder for dogs and cats. Uses a diamond drum bit grinder to file down nails safely and painlessly. Offers two speed settings and three grinding ports/openings to suit small, medium, or large pets' nails."
    },
    {
        "name": "Veterinary Formula Clinical Care Antiseptic & Antifungal Shampoo",
        "price": "$10-$15",
        "rating": "4.7/5",
        "description": "A medicated shampoo for dogs and cats that treats skin infections and dermatitis. Contains benzethonium chloride (antibacterial) and ketoconazole (antifungal) to help relieve issues like ringworm, fungal infections, dandruff, and pyoderma."
    },
    {
        "name": "Hertzko Self-Cleaning Slicker Brush (Original Purple Model)",
        "price": "$12-$17",
        "rating": "4.6/5",
        "description": "A well-known self-cleaning slicker brush for dogs and cats. Has fine, slightly angled wire bristles that effectively detangle and remove loose hair, mats, and dander from the coat. Gentle on pets' skin thanks to protective plastic tips on the bristles."
    },
    {
        "name": "KONG ZoomGroom Multi-Use Dog Brush",
        "price": "$7-$12",
        "rating": "4.7/5",
        "description": "A soft rubber grooming brush by KONG that is used for bathing and massaging. The ZoomGroom is a palm-sized, chunky rubber brush with gentle fingers that loosen and attract shed hair like a magnet. Excellent for short-haired and medium-coated dogs."
    },
    {
        "name": "WAHL Dry Skin & Itch Relief Dog Shampoo (Oatmeal Formula)",
        "price": "$10",
        "rating": "4.7/5",
        "description": "A large-bottle oatmeal dog shampoo by Wahl, formulated for moisturizing dry, itchy skin. Made with colloidal oatmeal, coconut, lime, aloe vera, and lemon verbena scent. This shampoo is gentle, alcohol-free, and paraben-free – great for dogs with sensitive skin."
    },
    {
        "name": "Pet Magasin Grooming Scissors Kit (2-Pack)",
        "price": "$12-$15",
        "rating": "4.7/5",
        "description": "A set of two grooming scissors for at-home trims: one larger straight scissor for body fur, and one smaller scissor with micro-serrated blades for delicate trimming around the face, paws, and other sensitive areas. Both have round safety tips."
    },
    {
        "name": "SleekEZ Original Deshedding Grooming Tool (5-Inch)",
        "price": "$15-$20",
        "rating": "4.8/5",
        "description": "The SleekEZ deshedding tool features a patented wave-pattern blade with tiny teeth mounted in a wooden handle. As you stroke it along the pet's coat, it painlessly grabs and pulls out loose undercoat hair without tugging on the skin."
    }
]

# Products that have images collected (first 15)
products_with_images = set([
    "Dipoo Self-Cleaning Slicker Brush",
    "PAWFUME Deshedding Dog Shampoo & Conditioner (Show Dog Scent)",
    "oneisall Low-Noise Dog Grooming Clippers Kit",
    "Hansprou High-Power 12V Professional Dog Clipper (Detachable Blade)",
    "Andis UltraEdge 2-Speed Detachable Blade Clipper (Model AGC2)",
    "3-Pack Silicone Dog Bath & Grooming Brushes",
    "LED Light Pet Nail Clipper (with Safety Quick Sensor)",
    "LEYOUFU Cordless Dog Paw Trimmer (Mini Grooming Clipper)",
    "IPX5 Waterproof Dog Hair Clipper (Low-Noise Cordless Trimmer)",
    "FURBB Five-Finger Pet Grooming Glove (Deshedding Mitt)",
    "Gonicc Dog & Cat Nail Clippers with Safety Guard",
    "FURminator Undercoat Deshedding Tool (for Dogs)",
    "Earth Rated Dog Grooming Wipes (Unscented) – 100 Count",
    "Casfuy Rechargeable Dog Nail Grinder (Quiet Electric Trimmer)",
    "Veterinary Formula Clinical Care Antiseptic & Antifungal Shampoo"
])

# Create CSV data
csv_data = []
csv_headers = [
    "product_name", "link", "price", "star_rating", "product_description", 
    "images_collected", "collection_status", "shipping_time", "other_info", "image_base_name"
]

for product in products_data:
    # Create Amazon search URL with affiliate tag
    search_query = quote_plus(product["name"])
    amazon_url = f"https://www.amazon.com/s?k={search_query}&tag=idls-20"
    
    # Determine image collection status
    images_collected = "Yes" if product["name"] in products_with_images else "No"
    collection_status = "Completed" if product["name"] in products_with_images else "Pending"
    
    # Create row
    row = [
        product["name"],            # product_name
        amazon_url,                 # link
        product["price"],           # price
        product["rating"],          # star_rating
        product["description"],     # product_description
        images_collected,           # images_collected
        collection_status,          # collection_status
        "",                         # shipping_time (empty as requested)
        "",                         # other_info (empty as requested)
        product["name"]             # image_base_name
    ]
    
    csv_data.append(row)

# Write to CSV file
with open('/home/ubuntu/dog_grooming_products_final.csv', 'w', newline='', encoding='utf-8') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(csv_headers)
    writer.writerows(csv_data)

print("Final CSV file created successfully!")
print(f"Total products: {len(csv_data)}")
print(f"Products with images: {len([p for p in products_data if p['name'] in products_with_images])}")
print(f"Products without images: {len([p for p in products_data if p['name'] not in products_with_images])}")
