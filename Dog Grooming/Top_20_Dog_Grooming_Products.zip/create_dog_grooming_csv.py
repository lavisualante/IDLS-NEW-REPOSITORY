#!/usr/bin/env python3
import csv
import re
from urllib.parse import quote_plus

# List of all 20 products in order
products = [
    "Dipoo Self-Cleaning Slicker Brush",
    "PAWFUME Deshedding Dog Shampoo & Conditioner (Show Dog Scent)",
    "oneisall Low-Noise Dog Grooming Clippers Kit",
    "Hansprou High-Power 12V Professional Dog Clipper (Detachable Blade)",
    "Andis UltraEdge 2-Speed Detachable Blade Clipper (Model AGC2)",
    "3-Pack Silicone Dog Bath & Grooming Brushes",
    "LED Light Pet Nail Clipper (with Safety Quick Sensor)",
    "LEYOUFU Cordless Dog Paw Trimmer (Mini Grooming Clipper)",
    "IPX5 Waterproof Dog Hair Clipper (Low-Noise Cordless Trimmer)",
    "FURBB Five-Finger Pet Grooming Glove (Deshedding Mitt)",
    "Gonicc Dog & Cat Nail Clippers with Safety Guard",
    "FURminator Undercoat Deshedding Tool (for Dogs)",
    "Earth Rated Dog Grooming Wipes (Unscented) – 100 Count",
    "Casfuy Rechargeable Dog Nail Grinder (Quiet Electric Trimmer)",
    "Veterinary Formula Clinical Care Antiseptic & Antifungal Shampoo",
    "Hertzko Self-Cleaning Slicker Brush (Original Purple Model)",
    "KONG ZoomGroom Multi-Use Dog Brush",
    "WAHL Dry Skin & Itch Relief Dog Shampoo (Oatmeal Formula)",
    "Pet Magasin Grooming Scissors Kit (2-Pack)",
    "SleekEZ Original Deshedding Grooming Tool (5-Inch)"
]

# Products that have images collected (first 15)
products_with_images = set(products[:15])

# Read the product details file
with open('/home/ubuntu/Uploads/user_message_2025-09-25_00-53-28.txt', 'r', encoding='utf-8') as f:
    content = f.read()

# Extract product information using regex patterns
def extract_product_info(product_name, content):
    # Find the section for this product
    pattern = rf"{re.escape(product_name)}.*?(?=\d+\.|$)"
    match = re.search(pattern, content, re.DOTALL | re.IGNORECASE)
    
    if not match:
        return "N/A", "N/A", "N/A"
    
    section = match.group(0)
    # Clean up the section by removing extra whitespace and line breaks
    section = re.sub(r'\s+', ' ', section)
    
    # Extract price
    price_match = re.search(r'Price:\s*[^$]*\$([0-9.,–-]+)', section)
    price = f"${price_match.group(1)}" if price_match else "N/A"
    
    # Extract rating - handle multi-line patterns
    rating_match = re.search(r'Rating:\s*~?([0-9.]+)\s*out of 5 stars', section)
    rating = f"{rating_match.group(1)}/5" if rating_match else "N/A"
    
    # Extract description (Use section)
    use_match = re.search(r'Use:\s*(.*?)(?=Price:|Rating:|Amazon Link:|$)', section, re.DOTALL)
    description = use_match.group(1).strip().replace('\n', ' ') if use_match else "N/A"
    
    return price, rating, description

# Create CSV data
csv_data = []
csv_headers = [
    "product_name", "link", "price", "star_rating", "product_description", 
    "images_collected", "collection_status", "shipping_time", "other_info", "image_base_name"
]

for product in products:
    # Create Amazon search URL with affiliate tag
    search_query = quote_plus(product)
    amazon_url = f"https://www.amazon.com/s?k={search_query}&tag=idls-20"
    
    # Extract product information
    price, rating, description = extract_product_info(product, content)
    
    # Determine image collection status
    images_collected = "Yes" if product in products_with_images else "No"
    collection_status = "Completed" if product in products_with_images else "Pending"
    
    # Create row
    row = [
        product,                    # product_name
        amazon_url,                 # link
        price,                      # price
        rating,                     # star_rating
        description,                # product_description
        images_collected,           # images_collected
        collection_status,          # collection_status
        "",                         # shipping_time (empty as requested)
        "",                         # other_info (empty as requested)
        product                     # image_base_name
    ]
    
    csv_data.append(row)

# Write to CSV file
with open('/home/ubuntu/dog_grooming_products.csv', 'w', newline='', encoding='utf-8') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(csv_headers)
    writer.writerows(csv_data)

print("CSV file created successfully!")
print(f"Total products: {len(csv_data)}")
print(f"Products with images: {len([p for p in products if p in products_with_images])}")
print(f"Products without images: {len([p for p in products if p not in products_with_images])}")
